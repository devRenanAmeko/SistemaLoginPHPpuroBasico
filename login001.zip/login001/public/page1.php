<?php
defined('CONTROL') or die('Acesso negado');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina 1</title>
</head>
<body>
    
    <?php require 'nav.php' ?>

    <h3>Pagina 1</h3>
    <hr>
    [conteudo]
    
</body>
</html>