<?php

//usuarios

return [
    [
    'usuario' => 'usuario1@gmail.com',
    'senha' => password_hash('senha001', PASSWORD_DEFAULT)
    ],
    [
    'usuario' => 'usuario2@gmail.com',
    'senha' => password_hash('senha002', PASSWORD_DEFAULT)
    ],
    [
    'usuario' => 'usuario3@gmail.com',
    'senha' => password_hash('senha003', PASSWORD_DEFAULT)
    ]
];